-- ==============================================================
-- Here is a Query of MSSQL for ISP POP / EZE / TCT cards ---
-- ===============================================================

-- name: isp_pop_active
SELECT p.ID, p.AlarmName, pop.NAME AS pop_name, pop.NCODE AS pop_code,
       p.DeviceName, p.IPAddress, p.DownTime, p.RestoredTime,
       p.Status, pop.Province, p.PROBLEM_DETAILS, p.NOTE,
       p.INTERFACE, p.RTID, p.SourceGroup, p.ADD_INFO,
       p.ACK, p.AB, p.MB, p.MD
FROM noc.TBL_PPD p
LEFT JOIN noc.TBL_ISPDEV isp ON p.IPAddress = isp.IP
LEFT JOIN noc.TBL_POP pop   ON isp.CODE   = pop.NCODE
WHERE p.AlarmName IN ('POP/PON DOWN', 'POP/PON POWER')
  AND (p.Status = 1 OR p.RestoredTime IS NULL)
  AND pop.NAME IS NOT NULL AND pop.NCODE IS NOT NULL;

-- name: eze_active
SELECT p.ID, p.AlarmName, SUBSTRING(p.AlarmName, 5, 200) AS alarm_type,
       p.DeviceName, p.IPAddress, p.DownTime, p.RestoredTime, p.Status,
       p.PROBLEM_DETAILS, p.NOTE, p.INTERFACE, p.RTID, p.SourceGroup, p.ADD_INFO,
       p.ACK, p.AB, p.MB, p.MD,
       pop.NAME AS pop_name, pop.NCODE AS pop_code, pop.Province
FROM noc.TBL_PPD p
LEFT JOIN noc.TBL_ISPDEV isp ON p.IPAddress = isp.IP
LEFT JOIN noc.TBL_POP pop   ON isp.CODE   = pop.NCODE
WHERE p.AlarmName LIKE 'EZE%' AND (p.Status = 1 OR p.RestoredTime IS NULL);

-- name: tct_active
SELECT p.ID, p.AlarmName, LOWER(SUBSTRING(p.AlarmName, 5, 200)) AS alarm_type,
       p.DeviceName, p.IPAddress, p.DownTime, p.RestoredTime, p.Status,
       p.PROBLEM_DETAILS, p.NOTE, p.INTERFACE, p.RTID, p.SourceGroup, p.ADD_INFO,
       p.ACK, p.AB, p.MB, p.MD,
       pop.NAME AS pop_name, pop.NCODE AS pop_code, pop.Province
FROM noc.TBL_PPD p
LEFT JOIN noc.TBL_ISPDEV isp ON p.IPAddress = isp.IP
LEFT JOIN noc.TBL_POP pop   ON isp.CODE   = pop.NCODE
WHERE p.AlarmName LIKE 'TCT%' AND (p.Status = 1 OR p.RestoredTime IS NULL);

-- name: it_node_active
-- IT_NODE alarms are IT infrastructure monitoring (e.g. "Dell R720: No SNMP
-- data collection"), unrelated to POP sites, so there's nothing to join
-- against TBL_ISPDEV/TBL_POP here unlike the other 3 alarm types above.
--
-- DeviceName/IPAddress ARE populated for this alarm type (~53.6% of the
-- time, confirmed against 1,715 historical rows) — a previous version of
-- this comment wrongly assumed they were always blank. PROBLEM_DETAILS,
-- NOTE, INTERFACE, and RTID are the ones that are always blank (0%
-- populated) for IT_NODE, so they're left out below; PROBABLE_CAUSE,
-- SourceGroup, and ADD_INFO are the fields that actually carry data.
SELECT AlarmName, DeviceName, IPAddress, DownTime, RestoredTime, Status,
       PROBABLE_CAUSE, SourceGroup, ADD_INFO
FROM noc.TBL_PPD
WHERE AlarmName = 'IT_NODE' AND (Status = 1 OR RestoredTime IS NULL);

-- name: acknowledge_note
-- Writes the Acknowledge/Modify popup's Note (already formatted as
-- "TT/INC-WOID: note text" by the caller) back to the real MSSQL row —
-- the only write-back to a source database anywhere in this app; every
-- other query here is read-only. ACK/AB are set only the first time a row
-- is ever acknowledged (ACK starts NULL) and never touched again; MD/MB
-- are set on every edit after that. All four CASE expressions read ACK's
-- pre-update value (SQL Server evaluates every expression in a SET clause
-- against the row's original values, not each other's newly-set values),
-- so this single statement is safe even if two staff submit for the same
-- row at nearly the same moment — whichever UPDATE commits second still
-- sees a consistent one-or-the-other outcome, never a mix of "first-ack"
-- and "later-edit" behavior in one write.
--
-- Matched by ID (the real uniqueidentifier primary key), NOT RTID —
-- confirmed live that RTID repeats across completely unrelated rows (same
-- RTID shared by an EZE_PORT alarm, a POP/PON DOWN alarm, and a POP/PON
-- POWER alarm on different devices), so filtering on RTID instead silently
-- updated 4 unrelated rows (including already-resolved ones) instead of
-- the 1 intended row when this was first tried. NOTE: never write a
-- literal "percent s" placeholder-looking sequence in a comment in this
-- file — pymssql's param substitution scans the whole raw query text
-- including comments, not just executable SQL, so a stray one here throws
-- off the real placeholder count below.
UPDATE noc.TBL_PPD
SET NOTE = %s,
    ACK = CASE WHEN ACK IS NULL THEN GETDATE() ELSE ACK END,
    AB  = CASE WHEN ACK IS NULL THEN %s ELSE AB END,
    MD  = CASE WHEN ACK IS NOT NULL THEN GETDATE() ELSE MD END,
    MB  = CASE WHEN ACK IS NOT NULL THEN %s ELSE MB END
WHERE ID = %s;
