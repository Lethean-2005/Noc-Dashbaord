"""Entry point: `python run.py`, or via the Flask CLI with `flask --app run run`.

APP_ENV (set in .env) selects the config class from app/config.py, which
determines the database connection, debug mode, and host/port.
"""
import os

from app import create_app

app = create_app(os.environ.get("APP_ENV", "development"))

if __name__ == "__main__":
    if app.config["DEBUG"]:
        # threaded=True: Werkzeug's dev server otherwise handles exactly one
        # request at a time — with several NOC staff hitting the dashboard
        # around the same moment, requests would queue up behind each other
        # instead of running concurrently. Kept for local development only,
        # since it still gives the Werkzeug auto-reloader/debugger that
        # waitress doesn't have.
        app.run(host=app.config["HOST"], port=app.config["PORT"], debug=True, threaded=True)
    else:
        # waitress: a real WSGI server (runs on Windows, unlike gunicorn) —
        # required, not just nicer, for anything beyond local dev. The
        # Werkzeug dev server sends `Connection: close` on every response,
        # which breaks NTLM's Windows-Auth handshake (see
        # app/routes/winauth.py) since that requires the same TCP
        # connection to carry the whole challenge/response exchange.
        from waitress import serve

        serve(app, host=app.config["HOST"], port=app.config["PORT"])
