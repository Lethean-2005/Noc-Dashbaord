// Acknowledge/Modify popup — EZE / TCT / ISP POP drilldown tables only
// (see drilldown/alarms.html + drilldown/_ack_button.html).
//
// This app has no login system (app/extensions.py's load_user() is a
// stub) and no website can read the visiting browser's Windows username —
// there is no browser API for that, by design. So "who acknowledged this"
// is captured client-side instead: the "Your Name" field is a normal
// editable input, pre-filled with whatever this browser last saved to
// localStorage (blank the very first time). Whatever is in the field at
// submit time is saved back to localStorage, so it's remembered next
// visit but can always be corrected inline if it's wrong — no browser-
// storage-clearing needed to fix a typo or a shared-computer mixup.
const ACK_USERNAME_KEY = 'nocAckUsername';

// Known-bad values that got cached by mistake before the popup's old
// server-account default (svc_nocremote, the VM's Flask process account)
// was removed — anyone who clicked OK without editing it during that
// window has this stuck in their browser's localStorage. Treating it as
// "nothing cached" here self-heals every affected browser the next time
// they open the popup, instead of requiring each person to manually clear
// their own browser storage.
const ACK_USERNAME_BLOCKLIST = new Set(['']);

function _cachedAckUsername() {
    const cached = localStorage.getItem(ACK_USERNAME_KEY) || '';
    if (ACK_USERNAME_BLOCKLIST.has(cached.toLowerCase())) {
        localStorage.removeItem(ACK_USERNAME_KEY);
        return '';
    }
    return cached;
}

// The stored NOTE is "TT/INC-WOID: note text" (see AlarmService.
// acknowledge_note() — it combines the two into MSSQL's single NOTE
// column). Splitting on the first ": " to pre-fill both fields is
// best-effort display only — if the existing note has no ": " in it
// (e.g. it was written by some other, older tool), the whole thing just
// goes into the Note field with TT/INC-WOID left blank, which is still
// safe to re-submit.
function _splitExistingNote(rawNote) {
    const sep = rawNote.indexOf(': ');
    if (sep === -1) return { ttIncWoId: '', note: rawNote };
    return { ttIncWoId: rawNote.slice(0, sep), note: rawNote.slice(sep + 2) };
}

function openAckModal(button) {
    const overlay = document.getElementById('ackModalOverlay');
    const { ttIncWoId, note } = _splitExistingNote(button.dataset.note || '');
    document.getElementById('ackId').value = button.dataset.id;
    document.getElementById('ackTtIncWo').value = ttIncWoId;
    document.getElementById('ackNote').value = note;

    const usernameField = document.getElementById('ackUsername');
    const cached = _cachedAckUsername();
    usernameField.value = cached;
    overlay.style.display = 'block';

    // Best-effort: if this browser can silently complete Windows
    // Authentication (see app/routes/winauth.py's /api/whoami), prefer the
    // real captured identity over the localStorage guess. Never blocks or
    // shows an error if this fails (off-domain machine, browser won't
    // negotiate silently, network hiccup, anything) — the field just keeps
    // its localStorage value in that case, same as before this existed.
    fetch('/api/whoami', { credentials: 'same-origin' })
        .then((res) => (res.ok ? res.json() : null))
        .then((data) => {
            if (!data || !data.username) return;
            // Only overwrite while the field still shows the cached
            // prefill — if the user already started typing something
            // else by the time this resolves, don't clobber it.
            if (usernameField.value === cached) {
                usernameField.value = data.username;
            }
        })
        .catch(() => {});
}

function closeAckModal() {
    document.getElementById('ackModalOverlay').style.display = 'none';
}

document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.getElementById('ackModalOverlay');
    const form = document.getElementById('ackForm');
    if (!overlay || !form) return;

    window.addEventListener('click', function (event) {
        if (event.target === overlay) closeAckModal();
    });

    form.addEventListener('submit', function () {
        const name = document.getElementById('ackUsername').value.trim();
        if (name) localStorage.setItem(ACK_USERNAME_KEY, name);
    });
});
