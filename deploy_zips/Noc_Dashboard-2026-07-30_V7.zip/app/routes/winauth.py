"""Windows Authentication (NTLM/Kerberos via pyspnego) routes — see
app/services/winauth/spnego_negotiator.py for the handshake engine.

Two routes, both driving the same negotiator:
- /whoami-test: human-readable diagnostic (plain text), kept for manual
  checks — this is what proved the mechanism works, but only once the app
  runs under a real WSGI server (waitress) instead of Flask's dev server,
  which sends `Connection: close` on every response and breaks NTLM's
  connection-bound handshake. See run.py.
- /api/whoami: JSON, consumed by app/static/js/acknowledge.js to
  auto-fill the Acknowledge popup's "Your Name" field with the real
  Windows identity when available. That JS call is always best-effort —
  a failure here (off-domain machine, browser won't negotiate silently,
  anything) is caught and silently ignored client-side, falling back to
  the existing localStorage value. Nothing else in the app depends on
  either of these routes succeeding.
"""
from typing import Optional

from flask import Blueprint, Response, jsonify, request

from app.services.winauth import spnego_negotiator

winauth_bp = Blueprint("winauth", __name__)


def _challenge(token: Optional[str] = None) -> Response:
    value = f"Negotiate {token}" if token else "Negotiate"
    return Response("Authentication required", 401, {"WWW-Authenticate": value})


@winauth_bp.route("/whoami-test")
def whoami_test():
    conn_key = (request.remote_addr, request.environ.get("REMOTE_PORT"))
    result = spnego_negotiator.step(conn_key, request.headers.get("Authorization"))

    if result.status == "complete":
        return f"Authenticated as: {result.username}"
    if result.status == "continue":
        return _challenge(result.challenge_token)
    return _challenge()


@winauth_bp.route("/api/whoami")
def api_whoami():
    conn_key = (request.remote_addr, request.environ.get("REMOTE_PORT"))
    result = spnego_negotiator.step(conn_key, request.headers.get("Authorization"))

    if result.status == "complete":
        return jsonify({"username": result.username})
    if result.status == "continue":
        return _challenge(result.challenge_token)
    return _challenge()
