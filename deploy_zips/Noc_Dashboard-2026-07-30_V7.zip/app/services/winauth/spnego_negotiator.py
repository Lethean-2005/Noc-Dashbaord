"""Server-side NTLM/Kerberos (SPNEGO) handshake, via pyspnego + Windows
SSPI — an alternative to fronting the app with IIS + Windows
Authentication, for when nobody has Administrator rights on the host to
set that up. Confirmed locally (see the ad-hoc test run during
development) that this takes exactly 2 round-trips over NTLM and resolves
`client_principal` to 'DOMAIN\\username' — Kerberos may complete in a
single round-trip instead, depending on the client/network.

This module only drives the handshake state machine. It has no opinion on
HTTP status codes or whether a failed/incomplete handshake should block a
request — that's each caller's decision (see app/routes/winauth.py's two
routes for the two current callers).
"""
import base64
import socket
import time
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import spnego

# How long an abandoned in-progress handshake is kept before being dropped
# — a real client completes the round-trip within milliseconds, so this is
# generous headroom, not a tuning knob.
_CONTEXT_TTL_SECONDS = 60

# conn_key -> (spnego server context, created_at). Keyed by (client IP,
# client port): that pair identifies the one TCP connection a browser
# keeps alive across the challenge/response round-trip, which is what the
# in-progress NTLM context must be correlated against — there is no
# higher-level session yet at this point in the request (this handshake is
# what would eventually establish one).
# NOTE: typing.Dict/Tuple/Optional used here instead of the newer `dict[...]`
# / `X | None` syntax — this app already got bitten once (webhook/common.py)
# by PEP 604 union syntax crashing on the VM's older Python at runtime; the
# typing-module spellings work on any Python 3.5+, no guessing required.
_contexts: Dict[tuple, Tuple[object, float]] = {}


@dataclass
class NegotiationResult:
    status: str  # "complete" | "continue" | "failed"
    username: Optional[str] = None
    challenge_token: Optional[str] = None


def _purge_expired():
    cutoff = time.time() - _CONTEXT_TTL_SECONDS
    for key in [k for k, (_, created_at) in _contexts.items() if created_at < cutoff]:
        del _contexts[key]


def step(conn_key: tuple, authorization_header: Optional[str]) -> NegotiationResult:
    """Advances (or starts) the handshake for `conn_key`. `authorization_header`
    is the raw incoming `Authorization` header value, e.g. 'Negotiate <base64>',
    or None/empty to mean "no token yet — issue the initial challenge."""
    _purge_expired()

    if not authorization_header or " " not in authorization_header:
        in_token = None
    else:
        scheme, _, encoded = authorization_header.partition(" ")
        if scheme.lower() not in ("negotiate", "ntlm"):
            return NegotiationResult(status="failed")
        try:
            in_token = base64.b64decode(encoded)
        except (ValueError, TypeError):
            return NegotiationResult(status="failed")

    ctx, _ = _contexts.get(conn_key, (None, None))
    if ctx is None:
        ctx = spnego.server(hostname=socket.gethostname())

    try:
        out_token = ctx.step(in_token)
    except spnego.exceptions.SpnegoError:
        _contexts.pop(conn_key, None)
        return NegotiationResult(status="failed")

    if ctx.complete:
        _contexts.pop(conn_key, None)
        return NegotiationResult(status="complete", username=ctx.client_principal)

    _contexts[conn_key] = (ctx, time.time())
    challenge = base64.b64encode(out_token).decode("ascii") if out_token else None
    return NegotiationResult(status="continue", challenge_token=challenge)
