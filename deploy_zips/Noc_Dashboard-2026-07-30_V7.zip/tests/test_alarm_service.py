"""Tests for AlarmService's ISP POP/EZE/TCT badge counts — these count
distinct POP sites with an active alarm of a given type, not the raw
number of alarm rows (several devices at the same site can each carry
their own row for the same alarm type). Mirrors the same "distinct sites,
not rows" behavior VipAlarmService.get_counts() already implements (see
tests/test_vip_alarm_service.py), including ignoring rows with no
pop_name at all.
"""
from app.services.alarm.alarm_service import AlarmService, EZE_TYPES


class FakeCacheRepo:
    def __init__(self, rows):
        self._rows = rows

    def fetch_all(self, table):
        return self._rows


def test_get_isp_pop_counts_counts_distinct_sites_not_alarm_rows():
    rows = [
        {"alarm": "POP/PON DOWN", "pop_name": "KOH_RONG1-MBT"},
        {"alarm": "POP/PON DOWN", "pop_name": "KOH_RONG1-MBT"},
        {"alarm": "POP/PON DOWN", "pop_name": "KOH_RONG1-MBT"},
        {"alarm": "POP/PON DOWN", "pop_name": "CHBAAMPOV-CFOCN-MCB"},
    ]
    svc = AlarmService(FakeCacheRepo(rows))

    counts = svc.get_isp_pop_counts()

    # 4 rows, but only 2 distinct sites (KOH_RONG1-MBT x3, CHBAAMPOV-CFOCN-MCB x1).
    assert counts["POP/PON DOWN"] == 2


def test_get_isp_pop_counts_ignores_rows_with_no_pop_name():
    rows = [{"alarm": "POP/PON DOWN", "pop_name": ""}]
    svc = AlarmService(FakeCacheRepo(rows))

    counts = svc.get_isp_pop_counts()

    assert counts["POP/PON DOWN"] == 0


def test_get_isp_pop_counts_returns_zero_for_type_with_no_rows():
    svc = AlarmService(FakeCacheRepo([]))

    counts = svc.get_isp_pop_counts()

    assert counts == {"POP/PON DOWN": 0, "POP/PON POWER": 0}


def test_get_eze_counts_counts_distinct_sites_not_alarm_rows():
    rows = [
        {"alarm": "PORT", "pop_name": "SITE-A"},
        {"alarm": "PORT", "pop_name": "SITE-A"},
        {"alarm": "PORT", "pop_name": "SITE-B"},
    ]
    svc = AlarmService(FakeCacheRepo(rows))

    counts = svc.get_eze_counts()

    assert counts["PORT"] == 2
    # Every other EZE type still comes back as 0, not missing.
    assert set(counts.keys()) == set(EZE_TYPES)
    assert counts["CPU"] == 0


def test_get_tct_counts_matches_case_insensitively_and_counts_distinct_sites():
    rows = [
        {"alarm": "bgp", "pop_name": "SITE-A"},
        {"alarm": "BGP", "pop_name": "SITE-A"},  # same site, different case - still 1
        {"alarm": "bgp", "pop_name": "SITE-B"},
    ]
    svc = AlarmService(FakeCacheRepo(rows))

    counts = svc.get_tct_counts()

    assert counts["bgp"] == 2
