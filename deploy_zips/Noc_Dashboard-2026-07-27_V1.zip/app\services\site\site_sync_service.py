"""Pulls Site records from PostgreSQL (object_160) and writes them into the
local cache (instance/localstorage.db). Mirrors the MSSQL alarm sync in
app/services/alarm/alarm_sync_service.py, but for the Postgres-backed Site table —
kept separate since the two sources are unrelated.
"""
from app.repositories.site.site_cache_repository import SiteCacheRepository
from app.repositories.site.site_repository import SiteRepository
from app.repositories.site.site_technology_cache_repository import SiteTechnologyCacheRepository
from app.repositories.site.site_technology_repository import SiteTechnologyRepository
from app.services.postgres_sync_utils import retry_fetch
from app.utils.logger import get_logger

logger = get_logger(__name__)

_TABLE = "site_cache"
_TECHNOLOGY_TABLE = "site_technology_cache"


class SiteSyncService:
    def __init__(self, site_repository=None, cache_repository=None,
                 site_technology_repository=None, site_technology_cache_repository=None):
        self.site_repository = site_repository or SiteRepository()
        self.cache_repository = cache_repository or SiteCacheRepository()
        self.site_technology_repository = site_technology_repository or SiteTechnologyRepository()
        self.site_technology_cache_repository = (
            site_technology_cache_repository or SiteTechnologyCacheRepository()
        )

    def sync(self):
        """Refresh the local Site cache from PostgreSQL.

        Both steps below are wrapped in their own try/except and `return`
        on failure instead of raising — this runs inside an infinite
        background loop (see site_scheduler.py), so any uncaught exception
        here would silently kill that loop forever.
        """
        try:
            rows = self.site_repository.fetch_all()
        except Exception as e:
            logger.error(f"Postgres Site sync failed: {e}")
            return

        normalized = [{c: row.get(c) for c in SiteCacheRepository.columns} for row in rows]
        try:
            self.cache_repository.replace_all(_TABLE, normalized)
        except Exception as e:
            logger.error(f"Site cache write failed: {e}")
            return
        logger.info(f"Synced {len(normalized)} row(s) into {_TABLE}")

    def sync_technology(self):
        """Refresh the local site technology inventory cache from
        object_227 — confirmed prone to "conflict with recovery" (see
        incident_sync_service.py's module docstring), so this goes through
        retry_fetch() same as every other object_227-touching sync."""
        rows = retry_fetch(self.site_technology_repository.fetch_all, "Site-technology")
        if rows is None:
            return

        normalized = [
            {"site_code": row.get("Site Code"), "technology": row.get("Technology")} for row in rows
        ]
        try:
            self.site_technology_cache_repository.replace_all(_TECHNOLOGY_TABLE, normalized)
        except Exception as e:
            logger.error(f"Site-technology cache write failed: {e}")
            return
        logger.info(f"Synced {len(normalized)} row(s) into {_TECHNOLOGY_TABLE}")
