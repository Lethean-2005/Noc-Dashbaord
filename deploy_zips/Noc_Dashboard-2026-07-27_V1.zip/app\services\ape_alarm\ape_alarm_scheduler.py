"""Background thread that keeps the local ape_alarm cache
(instance/localstorage.db) in sync with PostgreSQL (object_138). Mirrors
app/services/incident/incident_scheduler.py — same reasoning applies here.

Runs on its own, longer interval (APE_ALARM_SYNC_INTERVAL_SECONDS) rather
than sharing INCIDENT_SYNC_INTERVAL_SECONDS's 300s default — object_138 is
a 10M-row foreign table with no supporting index, so every sync does a
full unindexed scan on a live production replica. A longer interval keeps
that cost infrequent instead of hitting it as often as the much cheaper
Incident/Site queries.

start() is called once from app/__init__.py::create_app(). See
scheduler_utils.py for the shared loop/guard logic.
"""
from app.services.ape_alarm.ape_alarm_sync_service import ApeAlarmSyncService
from app.services.scheduler_utils import start_singleton_loop


def start(app, interval_seconds):
    service = ApeAlarmSyncService()

    def _work():
        service.sync()

    start_singleton_loop(
        app, _work, interval_seconds,
        thread_name="ape-alarm-cache-sync",
        log_message=f"ape_alarm cache sync started (every {interval_seconds}s)",
    )
