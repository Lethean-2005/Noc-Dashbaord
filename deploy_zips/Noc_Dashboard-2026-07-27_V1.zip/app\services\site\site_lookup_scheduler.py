"""Background thread that keeps the local site_lookup cache
(instance/localstorage.db) in sync with PostgreSQL (site_lookup_mv). Same
role as app/services/site/site_scheduler.py plays for object_160, kept as
its own loop since it's a different source view on its own schedule.

start() is called once from app/__init__.py::create_app(). See
scheduler_utils.py for the shared loop/guard logic.
"""
from app.services.scheduler_utils import start_singleton_loop
from app.services.site.site_lookup_sync_service import SiteLookupSyncService


def start(app, interval_seconds):
    service = SiteLookupSyncService()

    start_singleton_loop(
        app, service.sync, interval_seconds,
        thread_name="site-lookup-cache-sync",
        log_message=f"site_lookup cache sync started (every {interval_seconds}s)",
    )
