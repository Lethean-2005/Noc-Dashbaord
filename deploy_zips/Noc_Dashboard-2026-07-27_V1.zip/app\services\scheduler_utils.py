"""Shared "run this on a background loop, once per process" helper.

Every scheduler (alarm_scheduler.py, site_scheduler.py, incident_scheduler.py,
telegram_alert.py) used to repeat the same ~15 lines: a start-once guard (so
Flask's debug reloader can't accidentally start the loop twice in the same
process), a thread wrapping the work in `app.app_context()` (needed because
the loop runs on its own thread, outside any request, so Flask has no
"current app" otherwise), and a sleep between iterations. This factors that
shared shape into one place — each scheduler file now only says *what* to run
and *how often*, not how to run it forever.
"""
import threading
import time

from app.utils.logger import get_logger

logger = get_logger(__name__)

_guards = {}
_guards_lock = threading.Lock()


def start_singleton_loop(app, work, interval_seconds, thread_name, log_message, first_run_delay=None,
                          next_delay_fn=None):
    """Run `work()` forever on a daemon thread named `thread_name`, every
    `interval_seconds`, guarded so a second call with the same `thread_name`
    in this process is a no-op.

    `work` is called inside `app.app_context()` and wrapped in a catch-all
    try/except — each sync service already catches its own per-job errors
    (so a bad MSSQL/Postgres response doesn't reach here), but this is a last
    -resort backstop so a future uncaught exception logs and skips a cycle
    instead of silently killing the loop forever.

    `first_run_delay`, if given, waits that many seconds before the first run
    instead of running immediately (used by the Telegram alert loop, both so
    restarting the dev server can't immediately resend an alert, and so the
    first run lands on a clean clock-aligned time — see
    telegram_alert.py's _seconds_until_next_aligned_time()).

    `next_delay_fn`, if given, is called to compute the sleep after every
    run instead of the plain `interval_seconds`. Without this, that sleep is
    measured from the moment `work()` returns, so `work()`'s own runtime
    (network calls, disk I/O, etc.) shifts every following run later — and
    that shift compounds every cycle since nothing re-aligns to the clock.
    Telegram's alert passes a function here to stay pinned to clean clock
    boundaries (00:00, 04:00, 08:00, ...) instead of drifting later each send.
    """
    with _guards_lock:
        guard = _guards.setdefault(thread_name, {"started": False, "lock": threading.Lock()})

    with guard["lock"]:
        if guard["started"]:
            return
        guard["started"] = True

    def _loop():
        if first_run_delay is not None:
            time.sleep(first_run_delay)
        while True:
            with app.app_context():
                try:
                    work()
                except Exception as e:
                    logger.error(f"{thread_name} iteration failed: {e}")
            time.sleep(next_delay_fn() if next_delay_fn else interval_seconds)

    threading.Thread(target=_loop, daemon=True, name=thread_name).start()
    logger.info(log_message)
