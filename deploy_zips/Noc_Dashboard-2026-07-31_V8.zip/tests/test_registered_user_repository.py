"""Tests for RegisteredUserRepository — the ip_address -> username table
pushed by each PC's per-user logon script (see
scripts/register_user_logon.ps1, app/routes/winauth.py's
/api/register-user). Not a Postgres/MSSQL sync cache, so uses the real
SQLite file via the `app` fixture's temp instance path rather than a fake
repo, same as tests/test_cache_migration.py.
"""
from app.repositories.winauth.registered_user_repository import RegisteredUserRepository


def test_lookup_returns_none_when_never_registered(app):
    with app.app_context():
        repo = RegisteredUserRepository()

        assert repo.lookup("10.0.0.1") is None


def test_register_then_lookup_returns_the_username(app):
    with app.app_context():
        repo = RegisteredUserRepository()

        repo.register("10.0.0.1", "CAMGSMKH\\slethean")

        assert repo.lookup("10.0.0.1") == "CAMGSMKH\\slethean"


def test_register_overwrites_previous_registration_for_the_same_ip(app):
    with app.app_context():
        repo = RegisteredUserRepository()

        repo.register("10.0.0.1", "CAMGSMKH\\old_user")
        repo.register("10.0.0.1", "CAMGSMKH\\new_user")

        assert repo.lookup("10.0.0.1") == "CAMGSMKH\\new_user"


def test_different_ips_are_tracked_independently(app):
    with app.app_context():
        repo = RegisteredUserRepository()

        repo.register("10.0.0.1", "CAMGSMKH\\alice")
        repo.register("10.0.0.2", "CAMGSMKH\\bob")

        assert repo.lookup("10.0.0.1") == "CAMGSMKH\\alice"
        assert repo.lookup("10.0.0.2") == "CAMGSMKH\\bob"
