"""Tests for /api/whoami and /whoami-test (app/routes/winauth.py) — the
Windows Authentication (NTLM/Kerberos via pyspnego) routes that best-effort
auto-fill the Acknowledge popup's "Your Name" field. Only the branches that
don't require a real NTLM handshake are covered here (no Authorization
header, and a malformed one) — a real handshake needs actual Windows SSPI
credentials from a live browser, not something to fake in a unit test.
Always a soft failure either way: app/static/js/acknowledge.js treats any
non-200 here as "fall back to localStorage", never a hard error.

The "no Authorization header" case doesn't just get a bare "Negotiate"
challenge on a real Windows box: spnego.server().step(None) has Windows
SSPI eagerly produce a real initial negotiate token even with no input, so
the WWW-Authenticate value already carries a base64 token attached
("Negotiate <token>", not just "Negotiate") — confirmed running this suite
on this machine, hence the startswith check below rather than an exact
match on a token whose content isn't something this test should pin down.
"""


def test_api_whoami_without_authorization_header_challenges(client):
    response = client.get("/api/whoami")

    assert response.status_code == 401
    assert response.headers["WWW-Authenticate"].startswith("Negotiate")


def test_api_whoami_with_unknown_scheme_returns_401(client):
    response = client.get("/api/whoami", headers={"Authorization": "Basic dXNlcjpwYXNz"})

    assert response.status_code == 401


def test_api_whoami_with_malformed_base64_returns_401(client):
    response = client.get("/api/whoami", headers={"Authorization": "Negotiate not-valid-base64!!"})

    assert response.status_code == 401


def test_whoami_test_without_authorization_header_challenges(client):
    response = client.get("/whoami-test")

    assert response.status_code == 401
    assert response.headers["WWW-Authenticate"].startswith("Negotiate")


def test_whoami_test_with_malformed_base64_returns_401(client):
    response = client.get("/whoami-test", headers={"Authorization": "Negotiate not-valid-base64!!"})

    assert response.status_code == 401


def test_register_user_then_whoami_returns_it_without_any_ntlm_negotiation(client):
    """The core of the logon-script approach: once a PC's IP has registered
    a username, /api/whoami answers instantly from that — no Authorization
    header, no NTLM handshake, no 401 challenge at all."""
    register_response = client.post("/api/register-user", json={"username": "CAMGSMKH\\slethean"})
    assert register_response.status_code == 200

    whoami_response = client.get("/api/whoami")

    assert whoami_response.status_code == 200
    assert whoami_response.get_json() == {"username": "CAMGSMKH\\slethean"}


def test_register_user_rejects_blank_username(client):
    response = client.post("/api/register-user", json={"username": "   "})

    assert response.status_code == 400


def test_register_user_rejects_missing_username(client):
    response = client.post("/api/register-user", json={})

    assert response.status_code == 400


def test_register_user_rejects_overlong_username(client):
    response = client.post("/api/register-user", json={"username": "x" * 101})

    assert response.status_code == 400


def test_register_user_accepts_form_encoded_body_too(client):
    """register_user_logon.ps1 sends JSON, but the route also accepts a
    plain form body — cheap to support and matches every other POST route
    in this app (see acknowledge_alarm())."""
    response = client.post("/api/register-user", data={"username": "CAMGSMKH\\formuser"})

    assert response.status_code == 200
