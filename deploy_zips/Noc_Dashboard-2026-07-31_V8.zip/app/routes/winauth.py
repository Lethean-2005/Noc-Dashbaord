"""Windows username capture routes — two independent mechanisms feeding the
same purpose (auto-filling the Acknowledge popup's "Your Name" field):

- /api/register-user: POST, hit by a small per-user logon script running on
  each NOC PC (see scripts/register_user_logon.ps1) the moment someone logs
  into Windows there. Remembers "whoever's PC this IP is" via
  RegisteredUserRepository — genuinely silent and automatic, no browser
  negotiation, no login prompt, no AuthServerAllowlist policy needed, since
  nothing about it depends on the browser at all.
- /api/whoami: GET, consumed by app/static/js/acknowledge.js. Checks the
  registered-user cache by request.remote_addr FIRST (instant, always
  silent) — only falls back to the pyspnego NTLM/Kerberos handshake (see
  app/services/winauth/spnego_negotiator.py) if that PC's logon script
  hasn't registered anything yet. The NTLM path needs the browser to trust
  this server (AuthServerAllowlist) to be silent — the registered-user path
  doesn't, which is the whole reason it exists.
- /whoami-test: GET, human-readable diagnostic for the NTLM path
  specifically (deliberately does NOT check the registered-user cache, so
  it stays useful for testing that path in isolation) — this is what proved
  the NTLM mechanism works, but only once the app runs under a real WSGI
  server (waitress) instead of Flask's dev server, which sends
  `Connection: close` on every response and breaks NTLM's connection-bound
  handshake. See run.py.

Every route here is always best-effort — a failure (off-domain machine,
logon script never ran, browser won't negotiate silently, anything) is
caught and silently ignored client-side by acknowledge.js, falling back to
the existing localStorage value. Nothing else in the app depends on any of
these routes succeeding.
"""
from typing import Optional

from flask import Blueprint, Response, jsonify, request

from app.extensions import csrf
from app.repositories.winauth.registered_user_repository import RegisteredUserRepository
from app.services.winauth import spnego_negotiator

winauth_bp = Blueprint("winauth", __name__)
_registered_user_repository = RegisteredUserRepository()

_MAX_USERNAME_LENGTH = 100


def _challenge(token: Optional[str] = None) -> Response:
    value = f"Negotiate {token}" if token else "Negotiate"
    return Response("Authentication required", 401, {"WWW-Authenticate": value})


@winauth_bp.route("/whoami-test")
def whoami_test():
    conn_key = (request.remote_addr, request.environ.get("REMOTE_PORT"))
    result = spnego_negotiator.step(conn_key, request.headers.get("Authorization"))

    if result.status == "complete":
        return f"Authenticated as: {result.username}"
    if result.status == "continue":
        return _challenge(result.challenge_token)
    return _challenge()


@winauth_bp.route("/api/whoami")
def api_whoami():
    registered = _registered_user_repository.lookup(request.remote_addr)
    if registered:
        return jsonify({"username": registered})

    conn_key = (request.remote_addr, request.environ.get("REMOTE_PORT"))
    result = spnego_negotiator.step(conn_key, request.headers.get("Authorization"))

    if result.status == "complete":
        return jsonify({"username": result.username})
    if result.status == "continue":
        return _challenge(result.challenge_token)
    return _challenge()


@winauth_bp.route("/api/register-user", methods=["POST"])
@csrf.exempt
def register_user():
    """Hit by scripts/register_user_logon.ps1 at Windows logon on each NOC
    PC — never called from the dashboard's own pages, so it's exempt from
    CSRF (that protection is for this app's own browser-submitted forms,
    not a machine-to-machine call from a script that has no CSRF token to
    send). No further authentication on this endpoint: this app already has
    no login system anywhere (see app/extensions.py's load_user() stub),
    and the worst case of abuse is a caller mislabeling their OWN
    connecting IP — the same thing they could already do by just typing a
    different name into the Ack popup's always-editable field."""
    payload = request.get_json(silent=True) or {}
    username = (payload.get("username") or request.form.get("username") or "").strip()
    if not username or len(username) > _MAX_USERNAME_LENGTH:
        return jsonify({"error": "username is required and must be under 100 characters"}), 400

    _registered_user_repository.register(request.remote_addr, username)
    return jsonify({"status": "registered"})
