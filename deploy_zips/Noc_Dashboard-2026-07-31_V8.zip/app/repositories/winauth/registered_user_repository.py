"""Read/write access to the local winauth_registered_user table
(instance/localstorage.db) — NOT a Postgres/MSSQL sync cache like every
other repository in this project. This table holds ip_address -> username
pairs pushed by each PC's own per-user logon script (see
app/routes/winauth.py's /api/register-user); see app/database/cache.py's
init_cache_db() for why it's never auto-dropped.
"""
from datetime import datetime

from app.database.cache import get_cache_conn


class RegisteredUserRepository:
    def register(self, ip_address, username):
        """Remember that `username` is whoever is currently logged into the
        PC at `ip_address` — overwrites any previous registration for that
        IP (a PC's last logon always wins, unlike mentor_sites' add-once
        behavior)."""
        conn = get_cache_conn()
        try:
            conn.execute(
                "INSERT INTO winauth_registered_user (ip_address, username, registered_at) VALUES (?, ?, ?) "
                "ON CONFLICT(ip_address) DO UPDATE SET username = excluded.username, "
                "registered_at = excluded.registered_at",
                (ip_address, username, datetime.now().isoformat(timespec="seconds")),
            )
            conn.commit()
        finally:
            conn.close()

    def lookup(self, ip_address):
        """The username last registered for `ip_address`, or None if that
        PC's logon script has never run (or hasn't run since this cache was
        last cleared/the app was last restarted before SQLite's WAL file
        existed)."""
        conn = get_cache_conn()
        try:
            row = conn.execute(
                "SELECT username FROM winauth_registered_user WHERE ip_address = ?", (ip_address,)
            ).fetchone()
            return row["username"] if row else None
        finally:
            conn.close()
