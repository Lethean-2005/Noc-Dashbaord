# setup_user_registration.ps1
#
# Run this ONCE per NOC PC, as the person who normally uses that PC (no
# admin rights needed - this only creates a per-user Scheduled Task for
# the account running this script, not a machine-wide one).
#
# It installs register_user_logon.ps1 (must sit next to this script) as a
# task that fires every time this Windows user logs on, silently telling
# the NOC Dashboard server "this PC belongs to this Windows user" - see
# that script's own comments for details.
#
# Usage:
#   1. Copy both register_user_logon.ps1 and this script to the PC (any
#      folder, e.g. C:\NocDashboard\).
#   2. Right-click this file -> Run with PowerShell.
#      (If PowerShell blocks it: right-click -> Properties -> Unblock,
#      or run: powershell -ExecutionPolicy Bypass -File setup_user_registration.ps1)

$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$TargetScript = Join-Path $ScriptDir "register_user_logon.ps1"

if (-not (Test-Path $TargetScript)) {
    Write-Host "ERROR: register_user_logon.ps1 was not found next to this script ($ScriptDir)." -ForegroundColor Red
    Write-Host "Copy both files into the same folder and try again."
    exit 1
}

$TaskName = "NOC Dashboard User Registration"

$Action = New-ScheduledTaskAction -Execute "powershell.exe" `
    -Argument "-NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$TargetScript`""
$Trigger = New-ScheduledTaskTrigger -AtLogOn
$Settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable

Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger $Trigger -Settings $Settings `
    -Description "Registers this PC's Windows username with the NOC Dashboard so the Acknowledge popup can auto-fill it." `
    -Force | Out-Null

Write-Host "Scheduled task '$TaskName' installed - it will run automatically at every future logon." -ForegroundColor Green

# Also run it right now, so this session doesn't have to wait for the next logon.
Start-ScheduledTask -TaskName $TaskName
Write-Host "Ran it once now for this session too."
