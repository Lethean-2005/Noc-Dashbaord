# register_user_logon.ps1
#
# Runs automatically at Windows logon (see setup_user_registration.ps1,
# which installs this as a per-user Scheduled Task - no admin rights
# needed for that). Tells the NOC Dashboard server "this PC's current
# Windows user is DOMAIN\username" by POSTing to /api/register-user.
#
# This never shows anything to the user and never blocks logon - any
# failure (server unreachable, off the office network, VPN not connected
# yet, anything) is silently ignored. The dashboard's Acknowledge popup
# falls back to a manually-typed name if this hasn't registered anything
# yet for this PC's IP.
#
# Edit $ServerUrl below to match your deployment before distributing this
# script.

$ServerUrl = "http://172.16.8.145:5000/api/register-user"

$Username = "$env:USERDOMAIN\$env:USERNAME"
$Body = @{ username = $Username } | ConvertTo-Json

try {
    Invoke-RestMethod -Uri $ServerUrl -Method Post -Body $Body -ContentType "application/json" -TimeoutSec 5 | Out-Null
} catch {
    # Best-effort only - nothing to report, nothing to retry here. The
    # next logon (or the next time this task fires) tries again.
}
