"""Shared alarm-category keyword rules — used by both
app/services/vip/vip_alarm_service.py and
app/services/mentor/mentor_site_service.py to categorize a raw ape_alarm
row (event_name/additional_info) into a human badge category, since both
read the same underlying alarm shape and used to duplicate this list.
"""

# Same NE/connectivity event types ape_alarm.sql originally filtered on —
# any of these means the site itself is unreachable, not just one
# subsystem alarming. Matched as an EXACT (not substring) match against the
# lowercased event_name.
SITE_DOWN_EVENTS = {
    "nodeb is out of service", "enodeb is out of service", "csl fault",
    "ne is disconnected", "ne3sws agent not responding to requests",
    "the link between the server and the me is broken",
    "bts o&m link failure", "site abis control link broken",
}
