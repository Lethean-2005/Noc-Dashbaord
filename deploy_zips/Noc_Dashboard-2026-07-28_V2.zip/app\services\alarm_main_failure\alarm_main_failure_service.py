"""Business logic for the "Alarm Main Failure" card on the Custom
Dashboard (reports/index.html). Same architecture as
app/services/dg_on/dg_on_alarm_service.py — see that file for the full
reasoning, summarized here:

Reads from the local ape_alarm cache (instance/localstorage.db) that
app/services/ape_alarm/ape_alarm_scheduler.py keeps in sync in the
background — no query of its own, purely local. Narrows to alarms whose
event_name is a Main Failure variant: real event_name text is messy ("Main
Failure Alarm", "BASE STATION EXTERNAL ALARM NOTIFICATION:::Main Failure",
plus assorted typos), so this uses the same case-insensitive substring
check app/services/ran/ran_main_ac_alarm_service.py already uses for its
own "RAN Main AC Alarm" column, rather than an exact match.

Only rows whose site_code has a matching site_cache record are counted —
that cache already excludes off_air sites (see site_cache.sql), same "an
off_air site isn't legitimately down" call already made for RAN Site
Down/RAN Tech Down/Alarm Site Down. Without this, a Main Failure alarm
still open against a decommissioned site would show up with a blank Site
Name/Hub/Grade/Province instead of being excluded.

Hub and the 4 grade tiers (Diamond/Gold/Silver/Bronze) are two independent
dimensions from site_cache (hub_site / site_grade) — a site can be both a
hub site and graded, so a Main-Failure alarm there counts toward BOTH
badges (same explicit choice as dg_on_alarm_service.py).

get_details() enriches each row with its site's current Power-category
Incident/INC-WO (from incident_by_status) if any — no site-down Remark
cross-reference here, unlike ran_main_ac_alarm_service.py (not part of
this card's column list). Real incident_by_status.category value for a
Power incident is "Power" (title case) — confirmed against real data.

ape_alarm.nms is the alarm's own raw numeric vendor code straight from
object_138 — translated here via app/utils/nms.py's NMS_NAMES, same as
every other drilldown in this project.
"""
from app.repositories.ape_alarm.ape_alarm_cache_repository import ApeAlarmCacheRepository
from app.repositories.incident.incident_status_cache_repository import IncidentStatusCacheRepository
from app.repositories.site.site_cache_repository import SiteCacheRepository
from app.utils.datetime import elapsed_minutes
from app.utils.event_name import clean_event_name
from app.utils.nms import NMS_NAMES
from app.utils.ttl_cache import ttl_cache

_APE_ALARM_TABLE = "ape_alarm"
_SITE_TABLE = "site_cache"
_INCIDENT_STATUS_TABLE = "incident_by_status"

BADGE_TYPES = ("Hub", "Diamond", "Gold", "Silver", "Bronze")

_HUB_SITE_VALUES = {"hub-mw", "hub-router"}
_GRADE_BADGES = {"diamond": "Diamond", "gold": "Gold", "silver": "Silver", "bronze": "Bronze"}

_POWER_CATEGORY = "power"


def _is_main_failure(event_name):
    return "main failure" in (event_name or "").lower()


class AlarmMainFailureService:
    def __init__(
        self,
        ape_alarm_cache_repository=None,
        site_cache_repository=None,
        incident_status_cache_repository=None,
    ):
        self.ape_alarm_cache_repository = ape_alarm_cache_repository or ApeAlarmCacheRepository()
        self.site_cache_repository = site_cache_repository or SiteCacheRepository()
        self.incident_status_cache_repository = incident_status_cache_repository or IncidentStatusCacheRepository()

    def _main_failure_rows_with_site(self):
        alarm_rows = self.ape_alarm_cache_repository.fetch_all(_APE_ALARM_TABLE)
        site_by_code = {
            r["standard_code"]: r
            for r in self.site_cache_repository.fetch_all(_SITE_TABLE)
            if r.get("standard_code")
        }
        result = []
        for row in alarm_rows:
            if not _is_main_failure(row.get("event_name")):
                continue
            site = site_by_code.get(row.get("site_code"))
            if site is None:
                continue
            result.append((row, site))
        return result

    @ttl_cache(15)
    def get_counts(self):
        """{'Hub': n, 'Diamond': n, 'Gold': n, 'Silver': n, 'Bronze': n} —
        Hub and grade are independent dimensions, so a site can count
        toward both (see module docstring)."""
        counts = {t: 0 for t in BADGE_TYPES}
        for _, site in self._main_failure_rows_with_site():
            if (site.get("hub_site") or "").lower() in _HUB_SITE_VALUES:
                counts["Hub"] += 1
            badge = _GRADE_BADGES.get((site.get("site_grade") or "").lower())
            if badge:
                counts[badge] += 1
        return counts

    def get_details(self, badge_type=None):
        """Every cached Main-Failure ape_alarm row (for a site known to
        site_cache), enriched with its site's current Power-category
        Incident/INC-WO (from incident_by_status) if any, plus Hub
        Site/Site Grade/Province and outage_min computed at read time —
        optionally narrowed to one badge (matches get_counts()'s
        categorization)."""
        all_incidents = self.incident_status_cache_repository.fetch_all(_INCIDENT_STATUS_TABLE)
        power_incidents = [r for r in all_incidents if (r.get("category") or "").strip().lower() == _POWER_CATEGORY]
        incident_by_site = IncidentStatusCacheRepository.latest_by_site(power_incidents)

        rows = []
        for alarm, site in self._main_failure_rows_with_site():
            row = dict(alarm)
            inc = incident_by_site.get(row.get("site_code")) or {}
            row["event_name"] = clean_event_name(row.get("event_name"))
            row["outage_min"] = elapsed_minutes(row.get("occurred_at"))
            row["incident_id"] = inc.get("incident_id") or ""
            row["incident_numeric_id"] = inc.get("incident_numeric_id")
            row["wo_id"] = inc.get("wo_id") or ""
            row["wo_numeric_id"] = inc.get("wo_numeric_id")
            row["wo_created_at"] = inc.get("wo_created_at") or ""
            row["wo_status"] = inc.get("wo_status") or ""
            row["hub_site"] = inc.get("hub_site") or site.get("hub_site") or ""
            row["site_grade"] = inc.get("site_grade") or (site.get("site_grade") or "").capitalize()
            row["province"] = inc.get("province") or site.get("province") or ""
            row["nms"] = inc.get("nms") or NMS_NAMES.get(str(row.get("nms") or "").strip(), row.get("nms"))
            rows.append(row)

        if badge_type == "Hub":
            rows = [r for r in rows if r["hub_site"].lower() in _HUB_SITE_VALUES]
        elif badge_type in _GRADE_BADGES.values():
            rows = [r for r in rows if r["site_grade"] == badge_type]
        return rows
