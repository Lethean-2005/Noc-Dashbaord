// Acknowledge/Modify popup — EZE / TCT / ISP POP drilldown tables only
// (see drilldown/alarms.html + drilldown/_ack_button.html).
//
// This app has no login system (app/extensions.py's load_user() is a
// stub), so "who acknowledged this" is captured client-side instead: the
// FIRST time someone opens this popup on a given browser, a one-time
// prompt() asks for their name (pre-filled with the server's own default —
// see dashboard.py's drilldown()'s default_username — as a convenient
// starting suggestion, not a real identity, since it's the same value for
// every visitor on a shared server). Whatever they confirm is saved into
// that browser's own localStorage. Every popup after that, from that same
// browser, reuses the saved name automatically — the "Your Name" field
// itself is read-only (see alarms.html) so it can never be edited inline;
// correcting a wrong name means clearing this browser's localStorage.
const ACK_USERNAME_KEY = 'nocAckUsername';

function _resolveAckUsername(overlay) {
    let username = localStorage.getItem(ACK_USERNAME_KEY);
    if (username) return username;

    const suggested = overlay.dataset.defaultUsername || '';
    username = (window.prompt(
        'Your name (remembered on this computer for future Acknowledge/Modify actions):',
        suggested
    ) || suggested).trim();
    if (username) localStorage.setItem(ACK_USERNAME_KEY, username);
    return username;
}

// The stored NOTE is "TT/INC-WOID: note text" (see AlarmService.
// acknowledge_note() — it combines the two into MSSQL's single NOTE
// column). Splitting on the first ": " to pre-fill both fields is
// best-effort display only — if the existing note has no ": " in it
// (e.g. it was written by some other, older tool), the whole thing just
// goes into the Note field with TT/INC-WOID left blank, which is still
// safe to re-submit.
function _splitExistingNote(rawNote) {
    const sep = rawNote.indexOf(': ');
    if (sep === -1) return { ttIncWoId: '', note: rawNote };
    return { ttIncWoId: rawNote.slice(0, sep), note: rawNote.slice(sep + 2) };
}

function openAckModal(button) {
    const overlay = document.getElementById('ackModalOverlay');
    const { ttIncWoId, note } = _splitExistingNote(button.dataset.note || '');
    document.getElementById('ackId').value = button.dataset.id;
    document.getElementById('ackTtIncWo').value = ttIncWoId;
    document.getElementById('ackNote').value = note;
    document.getElementById('ackUsername').value = _resolveAckUsername(overlay);
    overlay.style.display = 'block';
}

function closeAckModal() {
    document.getElementById('ackModalOverlay').style.display = 'none';
}

document.addEventListener('DOMContentLoaded', function () {
    const overlay = document.getElementById('ackModalOverlay');
    if (!overlay) return;

    window.addEventListener('click', function (event) {
        if (event.target === overlay) closeAckModal();
    });
});
